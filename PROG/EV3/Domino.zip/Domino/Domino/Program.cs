﻿namespace Domino
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Game juego = new Game();
            juego.Iniciar();
        }
    }
}