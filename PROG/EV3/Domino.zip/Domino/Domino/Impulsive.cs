﻿namespace Domino
{
    public class Impulsive : Player
    {
        public Impulsive(string name) : base(name) { }

        //public override Ficha MakeMove()
        //{

        //}
    }
}
