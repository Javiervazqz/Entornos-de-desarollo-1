﻿namespace Domino
{
    public class Conservative : Player
    {
        public Conservative(string name) : base(name) { }

        //public override Ficha MakeMove()
        //{

        //}
    }
}
