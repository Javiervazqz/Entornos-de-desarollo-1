﻿namespace DamLibTest
{
    public class StackTest
    {
        //static void Main(string[] args)
        //{
        //    Stack<string> s = new Stack<string>();
        //    s.Push("Jose Mari");
        //    s.Push("Jose Manuel");
        //    s.Push("Josetrix");
        //    Console.WriteLine(s.ToString());
        //}
    }
}
