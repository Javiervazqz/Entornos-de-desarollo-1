﻿using System;

namespace DamLibTest
{
    //public class DictionaryTest
    //{
    //    static void Main(string[] args)
    //    {
    //        Dictionary<string, int> d = new Dictionary<string, int>();
    //        var result = d.Filter(
    //            (key, value) =>
    //            {
    //                return key.Contains("a") && value > 3;
    //            }
    //        );
    //    }
    //}
}


