﻿using System;

namespace TPVLib
{
    public class TicketLine
    {
        public Product product;
        public string barScan { get; set; }
        public string date;
    }
}
