﻿using System;

namespace TPVLib
{
    public class Ticket
    {
        public TicketHeader header = new TicketHeader();
        public TicketBody body = new TicketBody();
    }
}
