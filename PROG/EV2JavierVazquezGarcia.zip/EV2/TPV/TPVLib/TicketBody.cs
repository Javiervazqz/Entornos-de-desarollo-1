﻿using System;

namespace TPVLib
{
    public class TicketBody
    {
        public TicketLine[] Lines;
    }
}
