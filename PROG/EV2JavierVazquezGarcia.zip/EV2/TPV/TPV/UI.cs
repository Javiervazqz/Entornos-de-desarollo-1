﻿using System;

namespace TPV
{
    public class UI
    {
        public void ShowMainMenu()
        {

        }
        public int ReadOption()
        {
            int res = Console.ReadLine();
            return res;
        }
    }
}
