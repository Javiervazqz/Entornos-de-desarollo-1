﻿using System;

namespace Examen2JavierVazquezGarcia
{
    public delegate bool FilterDelegate(IShape shape);
    public class Blueprint : IBlueprint
    {
        List<IShape> shapes = new List<IShape>();
        public int ShapesCount => shapes.Count;
        public void AddShape(IShape shape)
        {
            if(shape == null)
                throw new Exception("Shape cannot be null");
            shapes.Add(shape);
        }

        public void Draw(ICanvas canvas)
        {
            for (int i = 0; i < ShapesCount; i++)
            {
                shapes[i].Draw(canvas);
            }
        }

        public List<IShape> GetShapes(FilterDelegate del)
        {
            return shapes;
        }

        public IShape GetShapeWithName(string name)
        {
            if (name == null)
                throw new Exception("Name cannot be null");
            for (int i  = 0; i < shapes.Count; i++)
            {
                if (shapes[i].Name == name)
                    return shapes[i];
            }
            return null;
        }

        public void RemoveShapeWithName(string name)
        {
            if (name == null)
                throw new Exception("Name cannot be null");
            for (int i = 0; i < shapes.Count; i++)
            {
                if (shapes[i].Name == name)
                    shapes.Remove(shapes[i]); 
            }
            return;
        }
    }
}
