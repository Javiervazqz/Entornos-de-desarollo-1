﻿using System;

namespace Examen2JavierVazquezGarcia
{
    public interface IShape
    {
        string Name { get; set; }
        Color color { get; set; }
        bool HasArea { get; }
        double Area { get; }
        double Perimeter { get; }
        Point2D Center { get; }
        Rect2D Rect { get; }
        virtual void Draw(ICanvas canvas)
        {
            canvas.SetColor(color);
        }
    }
}
