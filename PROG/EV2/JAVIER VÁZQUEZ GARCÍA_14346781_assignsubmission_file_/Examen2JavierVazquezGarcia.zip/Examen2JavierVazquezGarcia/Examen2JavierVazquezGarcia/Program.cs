﻿namespace Examen2JavierVazquezGarcia
{
    public class Program
    {
        static void Main(string[] args)
        {

        }
    }
}