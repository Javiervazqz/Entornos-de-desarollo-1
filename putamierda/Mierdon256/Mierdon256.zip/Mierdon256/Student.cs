﻿using System;

namespace Mierdon256
{
    public class Student : Person
    {
        public long NIA;
        public override void ExecuteTurn()
        {
        }
    }
}
