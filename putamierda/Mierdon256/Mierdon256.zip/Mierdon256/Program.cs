﻿using System.Security.Cryptography.X509Certificates;

namespace Mierdon256
{
    public class Program
    {
        public static Person CreatePerson()
        {
            //return new Person();
        }
        static void Main(string[] args)
        {
            //Person p = new Person();
            //Person p2 = new Person("Jose", Gender.MALE);
            //Teacher t = new Teacher(1);
            //Teacher t1 = new Teacher()
            //{
            //    Name = "juanito juan",
            //    gender = Gender.MALE
            //};
            //Graveyard g = new Graveyard();
            //Person j = new Teacher();
            //Teacher tuma = (Teacher)j;
            //tuma.bloodlust = 0;
        }
    }
}