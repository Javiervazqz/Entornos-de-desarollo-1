﻿using System;

namespace Mierdon256
{
    public class Director : Teacher
    {
        public override void ExecuteTurn()
        {
        }
    }
}
