﻿namespace Mierdon256
{
    public interface IPerro
    {
        void Metodo1();
        void Metodo2();
        void Metodo3();
        void Metodo4();
        void Metodo5();

    }
    public abstract class Perro
    {
        public abstract void Metodo1();
        public abstract void Metodo2();
        public abstract void Metodo3();
        public abstract void Metodo4();
        public abstract void Metodo5();
        
    }
}
