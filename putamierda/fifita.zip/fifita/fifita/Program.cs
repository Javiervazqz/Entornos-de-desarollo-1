﻿using System;

namespace fifita
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameObject o1 = new GameObject();
        }
    }
}
