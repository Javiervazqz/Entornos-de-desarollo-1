﻿using System;

namespace fifita
{
    public class Field
    {
        public Field()
        {
            List<GameObject> gameObjects = new List<GameObject>();
            int width, height;
        }
    }
}
