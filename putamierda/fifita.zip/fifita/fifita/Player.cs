﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace fifita
{
    public class Player : GameObject
    {
        enum Team
        {
            RAYO_VALLECANO,
            REAL_BETIS_BALONPIE
        }
        public Player()
        {
            double stamina;
            int number;
            Team team;
            double accuracy;

        }
    }
}