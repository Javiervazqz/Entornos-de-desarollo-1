﻿using System;

namespace fifita
{
    public class GameObject
    {
        public GameObject()
        {
            double x, y, z;
            double rx, ry, rz;
        }
    }
}
