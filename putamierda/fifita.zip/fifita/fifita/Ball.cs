﻿using System;

namespace fifita
{
    public class Ball : GameObject
    {
        public Ball()
        {
            double diameter;
        }

    }
}
